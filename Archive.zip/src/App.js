import logo from './logo.svg';
import './App.css';
import '../src/css/style.css'
import '../src/css/responsive.css'



import 'antd/dist/antd.css'
import RoutesNew from './Route/Routes';



function App() {
  return (
    <RoutesNew/>
  );
}

export default App;
