const images = {

    logo: require('../images/logo.png').default,
    plus: require('../images/plus_five.png').default,
    usermessage: require('../images/user_message.png').default,
    vector: require('../images/Vector.png').default,
    login13: require('../images/login13.jpg').default,
    Calender: require('../images/Calendar.svg').default,
    Calender2: require('../images/Calendar2.svg').default,
    Calender3: require('../images/Calendar3.svg').default,
    Calender4: require('../images/Calender4.svg').default,
    Calender5: require('../images/Calendar5.svg').default,
    Calender6: require('../images/Calendar6.svg').default,
    pluss: require('../images/plus.png').default,
    photo: require('../images/login.png').default,
    login2: require('../images/login2.png').default,
    vector1: require('../images/vector1.png').default,
    login: require('../images/logo-login.png').default,
    download: require('../images/user1.png').default,
    down: require('../images/user5.png').default,
    edit: require('../images/user.png').default,
    login2: require('../images/slider.png').default,
    user5: require('../images/user2.png').default,
    user6: require('../images/user3.png').default,
    user7: require('../images/user4.png').default,





}

export default images;